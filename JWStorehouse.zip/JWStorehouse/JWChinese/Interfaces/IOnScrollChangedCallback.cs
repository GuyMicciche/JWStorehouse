﻿namespace JWChinese
{
    public interface IOnScrollChangedCallback
    {
        void OnScroll(int horizontal, int vertical);
    }
}